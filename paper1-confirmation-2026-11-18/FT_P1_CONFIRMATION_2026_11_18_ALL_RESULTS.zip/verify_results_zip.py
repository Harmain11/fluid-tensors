"""Offline, read-only audit of a Colab-generated Paper 1 results ZIP.

Invoke: python -m ft_paper1_confirmation.verify_results_zip path/to/results.zip
Requires numpy (only for the question-cluster bootstrap calculation).
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import sys
import zipfile
from pathlib import PurePosixPath

try:
    from .confirmation_core import (bootstrap_mean, compare_replay,
                                    ensure_complete_grid, inferential_decision,
                                    paired_question_contrasts)
except ImportError:
    from confirmation_core import (bootstrap_mean, compare_replay,
                                   ensure_complete_grid, inferential_decision,
                                   paired_question_contrasts)


def verify_zip(path):
    with zipfile.ZipFile(path, "r") as archive:
        names = archive.namelist()
        if len(set(names)) != len(names):
            raise ValueError("Duplicate ZIP member names")
        for name in names:
            p = PurePosixPath(name)
            if p.is_absolute() or ".." in p.parts or "\\" in name:
                raise ValueError("Unsafe ZIP member")
        manifest = json.loads(archive.read("CHECKSUMS_SHA256.json"))
        if manifest.get("algorithm") != "sha256":
            raise ValueError("Missing SHA256 manifest")
        if set(manifest["files"]) != set(names)-{"CHECKSUMS_SHA256.json"}:
            raise ValueError("SHA256 manifest does not cover exactly all files")
        for name, digest in manifest["files"].items():
            computed = hashlib.sha256(archive.read(name)).hexdigest()
            if computed != digest:
                raise ValueError(f"SHA256 mismatch: {name}")

        protocol = json.loads(archive.read("LOCKED_P1_CONFIRMATION_PROTOCOL.json"))
        protocol_sha = hashlib.sha256(archive.read("LOCKED_P1_CONFIRMATION_PROTOCOL.json")).hexdigest()
        frozen = json.loads(archive.read("FROZEN_P1_CONFIRM_QUESTIONS.json"))
        raw = archive.read("P1_RESPONSE_GEOMETRY.jsonl")
        if raw and not raw.endswith(b"\n"):
            raise ValueError("Incomplete final JSONL line")
        rows = [json.loads(line) for line in raw.splitlines()]
        keys = [r["record_key"] for r in rows]
        if len(set(keys)) != len(keys):
            raise ValueError("Duplicated response records")
        for r in rows:
            if r["protocol_sha256"] != protocol_sha:
                raise ValueError("Response recorded under a different protocol")
            if (r["record_key"] != "|".join((r["stage"],r["hash"],r["direction"],
                                              r["variant"],r["template"]))):
                raise ValueError("Response record identity mismatch")
            expected = 1-float(r["full_displacement_l2"])/float(r["logit_tangent_l2"])
            if not math.isclose(expected, float(r["full_attenuation"]), rel_tol=1e-9, abs_tol=1e-9):
                raise ValueError("Attenuation does not match recorded norm ratio")
        old_ids=["gsm_"+h[:16] for h in protocol["archive_heldout_hashes"]]
        fresh_ids=["gsm_"+h[:16] for h in protocol["fresh_hashes"]]
        if {q['question_id'] for q in frozen['selection']['questions']} != set(fresh_ids):
            raise ValueError("Frozen question identities changed")
        if set(protocol["fresh_hashes"]) & set(protocol["all_historical_exclusion_hashes"]):
            raise ValueError("Frozen fresh questions overlap known historical exclusions")

        smoke = protocol['smoke_noninferential']
        replay_ids=old_ids[:2] if smoke else old_ids
        stages=(('original_replay',replay_ids,('signed',)),
                ('fresh_matched',fresh_ids,('signed','rotated_90')),
                ('fresh_raw',fresh_ids,('signed','rotated_90')))
        stage_stats={}
        pair_map={}
        for stage, qids, dirs in stages:
            subset=[r for r in rows if r['stage']==stage]
            ensure_complete_grid(subset,qids,dirs,
                                 ('original','reworded'),('generic','math_format'),stage)
            stage_stats[stage]={}
            for direction in dirs:
                drows=[r for r in subset if r['direction']==direction]
                pairs=paired_question_contrasts(drows)
                pair_map[(stage,direction)]=pairs
                stage_stats[stage][direction]=bootstrap_mean(
                    [p['contrast'] for p in pairs],10000,20261118)
        if len(rows)!=(8 if smoke else 128)+(32 if smoke else 1024):
            raise ValueError("Unrecognized count of complete scientific cells")
        with io.StringIO(archive.read('published_archive_source/CI_V2_RAW_RESPONSE_GEOMETRY.csv').decode()) as source:
            historical=list(csv.DictReader(source))
        reference=[dict(question_id=r['question_id'],direction=r['direction'],
                        variant=r['variant'],template=r['template'],
                        full_attenuation=float(r['attenuation'])) for r in historical
                   if r['question_id'] in set(replay_ids) and r['direction']=='signed'
                   and r['variant'] in ('original','reworded') and r['template'] in ('generic','math_format')]
        replay=compare_replay([r for r in rows if r['stage']=='original_replay'],reference,
                              tolerance=protocol['sample_replay_tolerance'])
        numeric_ok=not any(r.get('numeric_quality_flags') for r in rows) and replay['status']=='MATCH'
        decision=inferential_decision(stage_stats['fresh_matched']['signed'],numeric_ok,True,smoke)
        reported=json.loads(archive.read('P1_CONFIRMATION_SUMMARY.json'))
        if reported['status']!=decision['status']:
            raise ValueError("Headline status does not match independently calculated result")
        if reported['original_replay']['status']!=replay['status']:
            raise ValueError("Replay conclusion does not match historical reference")
        for stage in stage_stats:
            for direction in stage_stats[stage]:
                actual=stage_stats[stage][direction]
                claimed=reported['by_stage_and_direction'][stage][direction]
                for key in ('mean','n_questions','ci95'):
                    if actual[key]!=claimed[key]:
                        raise ValueError(f"Wrong {key} in {stage}/{direction} summary")

        return {'zip_manifest':'VALID','raw_cells':len(rows),
                'original_replay':replay,'status':decision['status'],
                'matched_primary':stage_stats['fresh_matched']['signed'],
                'numeric_ok':numeric_ok,
                'scope':'One model, one edit, last-token response geometry (not accuracy)'}


if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit("Usage: python -m ft_paper1_confirmation.verify_results_zip RESULTS.zip")
    print(json.dumps(verify_zip(sys.argv[1]),indent=2))
