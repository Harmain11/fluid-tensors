"""FT-CI-v2 frozen Colab runtime; this EXACT source is embedded, SHA-verified and archived.

Do not execute locally: the preceding Colab cells provide frozen torch modules,
model, archival checkpoints, statistical scorer, file helpers and registry.
"""

import sys
import transformers

# Rerunning only this cell would stack forward hooks on the same live model.
# A safe resume means restarting the kernel and running ALL notebook cells.
if globals().get('_FT_CI_V2_STARTED', False):
    raise RuntimeError('FT-CI-v2 runtime already initialized: restart the Colab runtime, then Run all for safe resume.')
_FT_CI_V2_STARTED = True


def effective_frob(editor):
    raw = float(editor.delta_weight_norm(editor.gates(None)).item())
    return min(raw, float(W_NORM)*float(MAX_EDIT_NORM_RATIO))


torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
torch.set_float32_matmul_precision('highest')
ENVIRONMENT = {'python': sys.version.split()[0], 'torch': torch.__version__,
               'transformers':transformers.__version__, 'cuda':str(torch.version.cuda),
               'gpu':torch.cuda.get_device_name(0),
               'allow_tf32_matmul':bool(torch.backends.cuda.matmul.allow_tf32),
               'allow_tf32_cudnn':bool(torch.backends.cudnn.allow_tf32)}
ENV_PATH = RUN/'LOCKED_RUNTIME_ENVIRONMENT.json'
if ENV_PATH.exists():
    assert json.loads(ENV_PATH.read_text()) == ENVIRONMENT, 'GPU/runtime drift on resume; use a new run name.'
else:
    atomic_json(ENV_PATH, ENVIRONMENT)

assert BASE_HASH == CI_V1_BASE_HASH == FEN_FP32_BASE_SHA == OGC_EXPECTED_BASE_HASH
assert {k:v['sha256'] for k,v in ASSET_DATA.items()} == CI_V1_CHECKPOINT_HASHES
assert abs(effective_frob(static)-CI_V1_EFFECTIVE_FROB) < 1e-4, 'Effective, not raw, norm must match CI-v1.'
check_frozen()

# These eight original/reworded literal prompts match the CI-v1 protocol.
PROMPT_VARIANTS = {
    'original':{t:PROMPTS[t] for t in TEMPLATES},
    'reworded':{
        'generic':'Give a careful and concise response to the following question.\n\nQuestion: ',
        'math_only':'Work out this arithmetic word problem carefully and concisely.\n\nQuestion: ',
        'format_only':'Give a careful and concise response to the following question. End with one line written exactly as: Final answer: <number>.\n\nQuestion: ',
        'math_format':'Work out this arithmetic word problem carefully and concisely. End with one line written exactly as: Final answer: <number>.\n\nQuestion: '},
    'formal':{
        'generic':'Please answer the following question precisely and briefly.\n\nQuestion: ',
        'math_only':'Please solve the following arithmetic word problem precisely and briefly.\n\nQuestion: ',
        'format_only':'Please answer the following question precisely and briefly. Finish with a line of the form Final answer: <number>.\n\nQuestion: ',
        'math_format':'Please solve the following arithmetic word problem precisely and briefly. Finish with a line of the form Final answer: <number>.\n\nQuestion: '},
    'terse':{
        'generic':'Answer concisely.\n\nQuestion: ',
        'math_only':'Solve the math word problem concisely.\n\nQuestion: ',
        'format_only':'Answer concisely. Last line: Final answer: <number>.\n\nQuestion: ',
        'math_format':'Solve the math word problem concisely. Last line: Final answer: <number>.\n\nQuestion: '}}
assert tuple(PROMPT_VARIANTS) == VARIANTS
assert all(tuple(PROMPT_VARIANTS[v])==TEMPLATES for v in VARIANTS)
assert len(set(PROMPT_VARIANTS[v][t] for v in VARIANTS for t in TEMPLATES)) == 16

def ids_for(question, variant, template):
    prompt = PROMPT_VARIANTS[variant][template]+question
    return [int(x) for x in tok.apply_chat_template(
        [{'role':'user','content':prompt}], tokenize=True, add_generation_prompt=True)]


# Historical exclusions include the CI-v1 fresh 44 questions, not only LRC-v1.
HISTORICAL_EXCLUSIONS = set(CI_V1_HISTORICAL_ALL_HASHES)
assert HISTORICAL_EXCLUSIONS.issuperset(set(CI_V1_ALL_HASHES))
assert HISTORICAL_EXCLUSIONS.issuperset(set(LRC_ALL_HASHES))
# The earlier v2 notebook mistakenly assumed >=44 unused GSM8K *test* items.
# Exhausting test is not a model failure. Freeze one complete split before
# inference: prefer test if sufficient, otherwise train, never mix splits.
gsm_lookups = {}
for split_name in ('test','train'):
    split_lookup={}
    for item in load_dataset('openai/gsm8k','main',split=split_name):
        question=str(item['question']).strip()  # NEVER read item['answer'].
        key=sha(question)
        assert key not in split_lookup,('Duplicate GSM8K identity',split_name)
        split_lookup[key]=question
    gsm_lookups[split_name]=split_lookup
ncal, nhold = (2,2) if SMOKE_TEST else (N_CAL,N_HOLD)
SELECTION=core_ns['select_fresh_question_cohort'](
    gsm_lookups['test'],gsm_lookups['train'],HISTORICAL_EXCLUSIONS,ncal+nhold,SALT)
SOURCE_SPLIT=SELECTION['source_split']
gsm_lookup=gsm_lookups[SOURCE_SPLIT]
selected=SELECTION['hashes']
print('New FT-CI-v2 cohort from GSM8K',SOURCE_SPLIT,
      'eligible test/train:',SELECTION['eligible_counts'],
      'selected',len(selected), 'all previous identities excluded')

def question_record(qhash):
    return {'question_id':'gsm_'+qhash[:16], 'hash':qhash,
            'question':gsm_lookup[qhash], 'domain':'gsm8k_'+SOURCE_SPLIT,
            'source_split':SOURCE_SPLIT}

calibration_questions = [question_record(h) for h in selected[:ncal]]
heldout_questions = [question_record(h) for h in selected[ncal:]]
cohort = {k:[{'question_id':v['question_id'],'hash':v['hash'],
               'domain':v['domain'],'source_split':v['source_split']} for v in xs]
          for k,xs in (('calibration',calibration_questions),('heldout',heldout_questions))}
cohort_path = RUN/'FROZEN_CI_V2_QUESTION_IDENTITIES.json'
if cohort_path.exists():
    assert json.loads(cohort_path.read_text())==cohort, 'Cohort changed on resume'
else:
    atomic_json(cohort_path,cohort)
texts = {item['hash']:item['question'] for item in calibration_questions+heldout_questions}
text_path = RUN/'FROZEN_CI_V2_QUESTION_TEXTS.json'
if text_path.exists():
    assert json.loads(text_path.read_text()) == texts, 'Question text drift'
else:
    atomic_json(text_path,texts)
assert not set(texts).intersection(HISTORICAL_EXCLUSIONS)


# Unchanged static rank-4 direction and equal-effective-norm 90-degree rotation.
A = static.A.detach().cpu().numpy().astype(np.float64)
B = static.B.detach().cpu().numpy().astype(np.float64)
orth = build_orthogonal_output_factor(A,B,ROTATION_SEED)
rot_B = rotate_output_factor(B,orth,90)
ROT_GEOMETRY = matrix_geometry(A,B,rot_B)
assert abs(ROT_GEOMETRY['cosine']) < 1e-8
assert abs(ROT_GEOMETRY['relative_norm']-1.) < 1e-8
rotated = RankEditor(False).to(DEVICE)
with torch.no_grad():
    rotated.A.copy_(static.A)
    rotated.B.copy_(torch.as_tensor(rot_B,dtype=torch.float32,device=DEVICE))
rotated.eval()
for param in rotated.parameters():param.requires_grad_(False)
assert abs(effective_frob(rotated)-CI_V1_EFFECTIVE_FROB)<1e-4
EDITORS = {'signed':static, 'rotated_90':rotated}

PROTOCOL = {
    'study':'FT_CI_V2_PROMPT_CONDITIONED_RESPONSE', 'smoke_noninferential':SMOKE_TEST,
    'model_id':MODEL_ID,'model_revision':MODEL_REV,'fp32_base_weight_sha256':BASE_HASH,
    'checkpoint_sha256':CI_V1_CHECKPOINT_HASHES,
    'ci_v1_archive_sha256':CI_V1_ARCHIVE_SHA,'ci_v1_protocol_sha256':CI_V1_PROTOCOL_SHA,
    'ci_v1_fresh_exclusions':CI_V1_ALL_HASHES,
    'all_historical_exclusions':sorted(HISTORICAL_EXCLUSIONS),
    'source_split':SOURCE_SPLIT,
    'eligible_question_counts_by_split':SELECTION['eligible_counts'],
    'source_split_policy':'Prefer entirely unused GSM8K test; if fewer than ncal+nhold, use entirely unused GSM8K train; never mix.',
    'train_split_caveat':'GSM8K train split may have been visible during original model pretraining; this is not a pristine benchmark-generalization sample.',
    'cohorts':cohort,'calibration_n':ncal,'heldout_n':nhold,
    'templates':list(TEMPLATES),'variants':list(VARIANTS),'directions':list(DIRECTIONS),
    'prompt_texts':PROMPT_VARIANTS,'patch_modes':list(PATCH_MODES),
    'patch_variants':list(PATCH_VARIANTS),'patch_directions':list(PATCH_DIRECTIONS),
    'microsteps':list(MICROSTEPS),'strengths':list(STRENGTHS),
    'rotation_seed':ROTATION_SEED,'rotation_geometry':ROT_GEOMETRY,
    'full_edit_frobenius':CI_V1_EFFECTIVE_FROB,
    'bootstrap_iterations':BOOTSTRAP_ITERATIONS,
    'primary_effect_cutoff':MIN_PRIMARY_EFFECT,
    'seed':SEED,'question_salt':SALT,'runtime':ENVIRONMENT,
    'core_code_sha256':CI_V2_CORE_SHA256,'rotation_code_sha256':ROTATION_SOURCE_SHA256,
    'exact_runtime_source_sha256':EXACT_EXECUTED_SOURCE_SHA256,
    'primary':'Signed original minus reworded (math_format minus generic) full-strength logit attenuation >=0.10 with question-cluster-bootstrap CI95 lower>0 on new heldout questions.',
    'prior_selection':'CI-v1 exploratory prior selected this contrast; no across-model claim.',
    'secondary':'All four variants, direction rotation, factorial interactions and raw norm/cosine decompositions.',
    'patch_interpretation':'Last-token-only off-manifold intervention sensitivity, never unique circuit identification.',
    'no_gold_answers':True,'no_training':True,'calibration_first':True}
protocol_path = RUN/'LOCKED_CI_V2_PROTOCOL.json'
if protocol_path.exists():
    assert json.loads(protocol_path.read_text()) == PROTOCOL, 'Frozen protocol drift; use new RUN_NAME.'
else:
    atomic_json(protocol_path, PROTOCOL)
PROTOCOL_SHA = sha_bytes(protocol_path.read_bytes())
atomic_json(RUN/'ROTATION_DIRECTION_GEOMETRY.json',ROT_GEOMETRY)
print('V2 protocol',PROTOCOL_SHA,'calibration',ncal,'heldout',nhold,
      'previous excluded',len(HISTORICAL_EXCLUSIONS))


# The old unconditional adapter hook must be removed, or edits would stack.
HOOK.remove()
active_editor = None
active_scale = 0.
active_patch = None
active_refs = None
last_local_edit = None
CAPTURED = {}

def vnorm(v):
    return float(np.linalg.norm(np.asarray(v,dtype=np.float64)))

def injection_hook(module, inputs, output):
    global last_local_edit
    if active_editor is None:return output
    delta = active_editor(inputs[0],None,W_NORM,MAX_EDIT_NORM_RATIO).to(output.dtype)
    last_local_edit = float(delta[0,-1].float().norm().item())
    return output+active_scale*delta

INJECTION_HOOK = proj.register_forward_hook(injection_hook)

def tensor_part(value):
    return value[0] if isinstance(value,(tuple,list)) else value

def replace_part(original,modified):
    if isinstance(original,tuple):return (modified,)+original[1:]
    if isinstance(original,list):return [modified]+original[1:]
    return modified

def trace_hook(name):
    def hook(module, inputs, output):
        tensor=tensor_part(output)
        assert tensor.ndim==3 and tensor.shape[0]==1, (name,tuple(tensor.shape))
        if active_patch is not None and name in active_refs:
            desired=active_refs[name]
            assert desired.ndim==1 and desired.shape[0]==tensor.shape[-1],name
            updated=tensor.clone()
            updated[:,-1,:]=desired.to(device=tensor.device,dtype=tensor.dtype)
            tensor=updated
            output=replace_part(output,updated)
        CAPTURED[name]=tensor[0,-1,:].detach().float().cpu().numpy().astype(np.float64)
        return output
    return hook

att20 = model.model.layers[20].self_attn
TRACE_HOOKS = [
    model.model.layers[19].register_forward_hook(trace_hook('block_19')),
    att20.q_proj.register_forward_hook(trace_hook('q20')),
    att20.k_proj.register_forward_hook(trace_hook('k20')),
    att20.v_proj.register_forward_hook(trace_hook('v20')),
    att20.o_proj.register_forward_hook(trace_hook('o20')),
    att20.register_forward_hook(trace_hook('attn20')),
    model.model.layers[20].mlp.register_forward_hook(trace_hook('mlp20')),
    model.model.layers[20].register_forward_hook(trace_hook('block_20'))]

@contextmanager
def editing(editor,scale):
    global active_editor,active_scale,last_local_edit
    assert active_editor is None
    active_editor,active_scale,last_local_edit = editor,float(scale),None
    try:yield
    finally:active_editor,active_scale=None,0.

@contextmanager
def patching(mode=None,refs=None):
    global active_patch,active_refs
    assert active_patch is None and (mode is None or mode in PATCH_MODES)
    active_patch,active_refs=mode,refs
    try:yield
    finally:active_patch,active_refs=None,None

@torch.inference_mode()
def trace(item, variant, template, editor=None, scale=0., mode=None, refs=None):
    CAPTURED.clear()
    input_ids=torch.tensor([ids_for(item['question'],variant,template)],
                           dtype=torch.long,device=DEVICE)
    with editing(editor,scale),patching(mode,refs):
        output=model(input_ids=input_ids,use_cache=False)
        expected=set(MONITORED)-{'logits'}
        assert set(CAPTURED)==expected, ('missing trace hooks',sorted(expected-set(CAPTURED)))
        record=dict(CAPTURED)
        record['logits']=output.logits[0,-1,:].detach().float().cpu().numpy().astype(np.float64)
        local=last_local_edit
    assert all(np.isfinite(x).all() for x in record.values()),'Nonfinite activation'
    del output,input_ids
    return record,local


def difference(a,b):
    return {name:a[name]-b[name] for name in MONITORED}

def scaled_difference(a,b,divisor):
    return {name:(a[name]-b[name])/divisor for name in MONITORED}

def measure_full(item,direction,variant,template):
    editor=EDITORS[direction]
    baseline,_=trace(item,variant,template)
    repeated,_=trace(item,variant,template)
    derivatives={}
    small={}
    local=None
    for h in MICROSTEPS:
        plus,local_value=trace(item,variant,template,editor,+h)
        minus,_=trace(item,variant,template,editor,-h)
        derivatives[h]=scaled_difference(plus,minus,2*h)
        small[h]=plus
        if h==min(MICROSTEPS):local=local_value
    assert local is not None and local>0, 'Missing applied local weight edit'
    deriv=derivatives[min(MICROSTEPS)]
    fulls={}
    full_trace=None
    for s in STRENGTHS:
        current=small.get(s)
        if current is None:current,_=trace(item,variant,template,editor,s)
        fulls[str(s)]=response_metrics(deriv['logits'],current['logits']-baseline['logits'],s)
        if s==1.:full_trace=current
    assert full_trace is not None
    full=fulls['1.0']
    b19=response_metrics(deriv['block_19'],full_trace['block_19']-baseline['block_19'],1.)
    b20=response_metrics(deriv['block_20'],full_trace['block_20']-baseline['block_20'],1.)
    conv={name:vnorm(derivatives[.005][name]-derivatives[.01][name])/
          max(vnorm(derivatives[.005][name]),1e-30) for name in MONITORED}
    return {
      'question_id':item['question_id'],'hash':item['hash'],'direction':direction,
      'variant':variant,'template':template,
      'record_key':'|'.join((item['hash'],direction,variant,template)),
      'protocol_sha256':PROTOCOL_SHA,'prompt_tokens':len(ids_for(item['question'],variant,template)),
      'full_attenuation':full['attenuation'],'full_cosine':full['cosine_to_tangent'],
      'full_displacement_l2':full['response_l2'],'logit_tangent_l2':full['tangent_norm'],
      'tangent_convergence':conv['logits'],
      'baseline_repeat_l2':vnorm(repeated['logits']-baseline['logits']),
      'block19_attenuation':b19['attenuation'],'block19_cosine':b19['cosine_to_tangent'],
      'block20_attenuation':b20['attenuation'],
      'strengths':fulls,'tangent_convergence_locations':conv,
      'baseline_repeat_block19_l2':vnorm(repeated['block_19']-baseline['block_19']),
      'last_token_edit_l2':float(local),'effective_edit_frob':effective_frob(editor)}


def random_reference(full,linear,key,label):
    error=full-linear
    size=vnorm(error)
    if size<1e-12:return full.copy()
    random_seed=int(sha(key+'/'+label)[:16],16)
    random_vec=np.random.default_rng(random_seed).standard_normal(full.shape)
    random_vec-=float(np.dot(random_vec,error)/max(np.dot(error,error),1e-30))*error
    random_norm=vnorm(random_vec)
    assert random_norm>1e-12,'Degenerate random direction'
    return full+(size/random_norm)*random_vec


def patch_references(baseline,deriv,full,key):
    def target(name):return baseline[name]+deriv[name]
    refs={
        'sham20':{'block_20':full['block_20']},
        'linear_block20':{'block_20':target('block_20')},
        'linear_attn20':{'attn20':target('attn20')},
        'linear_mlp20':{'mlp20':target('mlp20')},
        'linear_q20':{'q20':target('q20')},
        'linear_k20':{'k20':target('k20')},
        'linear_v20':{'v20':target('v20')},
        'linear_o20':{'o20':target('o20')},
    }
    for position,label in [('attn20','random_attn20'),('block_20','random_block20')]:
        for suffix in ('a','b'):
            name=label+'_'+suffix
            refs[name]={position:random_reference(full[position],target(position),key,name)}
    assert set(refs)==set(PATCH_MODES)-{'unpatched'}
    return refs


def measure_patches(item,variant,template):
    editor=EDITORS['signed']
    baseline,_=trace(item,variant,template)
    plus,_=trace(item,variant,template,editor,+.005)
    minus,_=trace(item,variant,template,editor,-.005)
    deriv=scaled_difference(plus,minus,.01)
    full,_=trace(item,variant,template,editor,1.)
    key='|'.join((item['hash'],'signed',variant,template))
    refs=patch_references(baseline,deriv,full,key)
    modes={'unpatched':response_metrics(deriv['logits'],full['logits']-baseline['logits'],1.)}
    diagnostics={}
    for mode in PATCH_MODES[1:]:
        dictionary={loc:torch.as_tensor(vec,dtype=torch.float32,device=DEVICE)
                    for loc,vec in refs[mode].items()}
        patched,_=trace(item,variant,template,editor,1.,mode=mode,refs=dictionary)
        modes[mode]=response_metrics(deriv['logits'],patched['logits']-baseline['logits'],1.)
        for loc,requested in refs[mode].items():
            # Measure whether this hook wrote its requested tensor, without
            # dividing by a near-zero local derivative of an unused path.
            target_error=vnorm(patched[loc]-requested)/max(vnorm(requested),1e-12)
            diagnostics[mode+'_'+loc+'_target_relative_error']=target_error
        if mode=='sham20':
            diagnostics['sham_relative_l2']=(
                vnorm(patched['logits']-full['logits']) /
                max(vnorm(full['logits']-baseline['logits']),1e-30))
        elif mode.startswith('random_'):
            loc=next(iter(refs[mode]))
            required=vnorm(full[loc]-(baseline[loc]+deriv[loc]))
            actual=vnorm(patched[loc]-full[loc])
            # fp32 assignment can round an extremely small random patch.
            diagnostics[mode+'_distance_relative_error']=(
                abs(required-actual)/max(required,1e-6*vnorm(full[loc]),1e-30))
    assert 'sham_relative_l2' in diagnostics
    return {'question_id':item['question_id'],'hash':item['hash'],
            'direction':'signed','variant':variant,'template':template,
            'record_key':key,'protocol_sha256':PROTOCOL_SHA,
            'modes':modes,'patch_diagnostics':diagnostics,
            'prompt_tokens':len(ids_for(item['question'],variant,template))}


def run_stage(items,output_name,stage,description):
    path=RUN/output_name
    saved=load_jsonl(path)
    cases=[(item,d,v,t) for item in items
           for d in (DIRECTIONS if stage=='full' else PATCH_DIRECTIONS)
           for v in (VARIANTS if stage=='full' else PATCH_VARIANTS)
           for t in TEMPLATES]
    allkeys={'|'.join((item['hash'],d,v,t)) for item,d,v,t in cases}
    assert set(saved).issubset(allkeys),'Unexpected saved grid; refusing resume'
    for row in saved.values():
        assert row['protocol_sha256']==PROTOCOL_SHA, 'Resume record from wrong protocol'
    for n,(item,d,v,t) in enumerate(cases,1):
        key='|'.join((item['hash'],d,v,t))
        if key not in saved:
            result=(measure_full(item,d,v,t) if stage=='full'
                    else measure_patches(item,v,t))
            assert result['record_key']==key
            append_jsonl(path,result)
            saved[key]=result
        if n % (len(TEMPLATES)*len(PATCH_VARIANTS if stage=='patch' else VARIANTS)*
                len(PATCH_DIRECTIONS if stage=='patch' else DIRECTIONS))==0:
            check_frozen()
            print(description,'question',n//(len(cases)//len(items)),
                  len(saved),'/',len(cases),flush=True)
    assert set(saved)==allkeys,'Incomplete cohort'
    return [saved[k] for k in sorted(allkeys)]


def export(reason='complete'):
    manifest={}
    for p in sorted(RUN.rglob('*')):
        if p.is_file() and p.name!='CONTENT_SHA256_MANIFEST.json':
            manifest[str(p.relative_to(RUN))]=sha_bytes(p.read_bytes())
    atomic_json(RUN/'CONTENT_SHA256_MANIFEST.json',
                {'files':manifest,'reason':reason,'protocol_sha256':PROTOCOL_SHA})
    bundle=RUN.parent/(RUN.name+'_results.zip')
    with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(RUN.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(RUN))
    print('Exported complete v2 audit archive:',bundle,'bytes',bundle.stat().st_size)
    if AUTO_DOWNLOAD_RESULTS:
        from google.colab import files
        files.download(str(bundle))


# Stage A/B calibration; quality gates have no access to heldout data.
calibration_full = run_stage(calibration_questions,'ci_v2_calibration_full.jsonl','full','calibration full')
calibration_patch = run_stage(calibration_questions,'ci_v2_calibration_patch.jsonl','patch','calibration patch')
cal_full_decision=score_conditions(calibration_full,expected_questions=ncal,
     bootstrap_iterations=BOOTSTRAP_ITERATIONS,seed=SEED,
     min_effect=MIN_PRIMARY_EFFECT,smoke=SMOKE_TEST)
cal_patch_decision=core_ns['score_patch_effects'](calibration_patch,
     expected_questions=ncal,bootstrap_iterations=BOOTSTRAP_ITERATIONS,
     seed=SEED+1,smoke=SMOKE_TEST,modes=PATCH_MODES)
cal_cross_stage=core_ns['cross_stage_consistency'](calibration_full,calibration_patch)
numeric_gate={'full':cal_full_decision['numerical_gate'],
              'patch':cal_patch_decision['numerical_gate'],
              'cross_stage_mismatches':cal_cross_stage,
              'passed':(cal_full_decision['numerical_gate']['invalid_count']==0 and
                        cal_patch_decision['numerical_gate']['invalid_count']==0 and
                        not cal_cross_stage),
              'decision_basis':'calibration numeric integrity only, not selected for effect size'}
atomic_json(RUN/'NUMERICAL_CALIBRATION_GATE.json',numeric_gate)
if not numeric_gate['passed']:
    atomic_json(RUN/'INCONCLUSIVE_EARLY_STOP.json',
                {'status':'NUMERIC_INCONCLUSIVE','do_not_run_heldout':True,
                 'instruction':'Do not change numerical thresholds after seeing any heldout result.'})
    export('calibration_numeric_failure')
assert numeric_gate['passed'], 'Numerical calibration failed; heldout must remain sealed.'
print('Calibration gate passed. Heldout is only now being opened.')


# Frozen new question cohort; no inspection-driven changes.
heldout_full=run_stage(heldout_questions,'ci_v2_heldout_full.jsonl','full','heldout full')
heldout_patch=run_stage(heldout_questions,'ci_v2_heldout_patch.jsonl','patch','heldout patch')
check_frozen()
heldout_decision=score_conditions(heldout_full,expected_questions=nhold,
     bootstrap_iterations=BOOTSTRAP_ITERATIONS,seed=SEED,
     min_effect=MIN_PRIMARY_EFFECT,smoke=SMOKE_TEST)
patch_decision=core_ns['score_patch_effects'](heldout_patch,
     expected_questions=nhold,bootstrap_iterations=BOOTSTRAP_ITERATIONS,
     seed=SEED+1,smoke=SMOKE_TEST,modes=PATCH_MODES)
heldout_cross_stage=core_ns['cross_stage_consistency'](heldout_full,heldout_patch)
if heldout_cross_stage:
    heldout_decision['status']='NUMERIC_INCONCLUSIVE'
    patch_decision['status']='NUMERIC_INCONCLUSIVE'
heldout_decision['cross_stage_mismatches']=heldout_cross_stage
patch_decision['cross_stage_mismatches']=heldout_cross_stage
atomic_json(RUN/'CI_V2_PRIMARY_CLAIM_DECISION.json',heldout_decision)
atomic_json(RUN/'CI_V2_EXPLORATORY_PATCH_ANALYSIS.json',patch_decision)
atomic_json(RUN/'FROZEN_ANALYSIS_MANIFEST.json',
    {'study':PROTOCOL['study'],'protocol_sha256':PROTOCOL_SHA,
     'exact_executed_source_sha256':EXACT_EXECUTED_SOURCE_SHA256,
     'core_sha256':CI_V2_CORE_SHA256,'prior_ci_v1_archive_sha256':CI_V1_ARCHIVE_SHA,
     'n_cal_full':len(calibration_full),'n_cal_patch':len(calibration_patch),
     'n_heldout_full':len(heldout_full),'n_heldout_patch':len(heldout_patch),
     'numeric_calibration_passed':numeric_gate['passed'],'smoke':SMOKE_TEST,
     'completed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})


# Preserve raw condition means, prompt lengths and branch patch comparisons.
pd.DataFrame([{'question_id':r['question_id'],'direction':r['direction'],
               'variant':r['variant'],'template':r['template'],
               'prompt_tokens':r['prompt_tokens'],
               'attenuation':r['full_attenuation'],'cosine':r['full_cosine'],
               'raw_logit_displacement':r['full_displacement_l2'],
               'tangent_norm':r['logit_tangent_l2']} for r in heldout_full]).to_csv(
               RUN/'CI_V2_RAW_RESPONSE_GEOMETRY.csv',index=False)
pd.DataFrame([{'question_id':r['question_id'],'variant':r['variant'],
               'template':r['template'],
               **{m+'_attenuation':r['modes'][m]['attenuation'] for m in PATCH_MODES},
               **r['patch_diagnostics']} for r in heldout_patch]).to_csv(
               RUN/'CI_V2_PATCH_INTERVENTION_MATRIX.csv',index=False)

import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(13,5))
for index,variant in enumerate(VARIANTS):
    values=[heldout_decision['variants'][variant]['signed']['cell_means'][t] for t in TEMPLATES]
    axes[0].plot(range(4),values,marker='o',label=variant)
axes[0].set_xticks(range(4),TEMPLATES,rotation=30,ha='right')
axes[0].set_ylabel('Full-strength logit response attenuation')
axes[0].set_title('Signed edit: individual means change with wording')
axes[0].legend()
for v in PATCH_VARIANTS:
    values=[patch_decision['interaction_reductions'][v][m]['mean'] for m in PATCH_MODES[1:]]
    axes[1].plot(range(len(PATCH_MODES)-1),values,marker='.',label=v)
axes[1].set_xticks(range(len(PATCH_MODES)-1),PATCH_MODES[1:],rotation=70,ha='right')
axes[1].axhline(0,color='black',linewidth=.7)
axes[1].set_ylabel('Interaction reduction vs unpatched')
axes[1].set_title('Exploratory intervention sensitivities, NOT circuit proof')
axes[1].legend()
fig.tight_layout()
fig.savefig(RUN/'CI_V2_PROMPT_RESPONSE_AND_PATCH_SENSITIVITY.png',dpi=175)
plt.close(fig)
print('Primary status:',heldout_decision['status'])
print('Original minus reworded MF-G:',
      heldout_decision['primary']['original_minus_reworded_mf_vs_generic'])
print('Attention sensitivity:',patch_decision['prompt_conditioned_attention_advantage'])
print('Caution: A positive finding here is NOT a confirmed world-first scientific discovery.')
export()
