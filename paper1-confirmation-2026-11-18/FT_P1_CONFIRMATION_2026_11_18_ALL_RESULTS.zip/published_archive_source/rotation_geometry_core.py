"""Pure-NumPy scientific core for frozen Fluid Tensors output-factor rotations.

No model, dataset, gold answer or network dependency. Embedded unchanged in
the self-contained Colab, so local tests exercise the same calculations.
"""

from __future__ import annotations

import math

import numpy as np


FULL_ANGLES = (15, 30, 45, 60, 90)


def _factors(A, B):
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    if A.ndim != 2 or B.ndim != 2 or A.shape[0] != B.shape[1]:
        raise ValueError('low-rank factor dimensions are incompatible')
    if not np.isfinite(A).all() or not np.isfinite(B).all():
        raise ValueError('nonfinite low-rank factor')
    gram = A @ A.T
    return A, B, gram


def _weighted_dot(B1, B2, gram):
    return float(np.sum((B1 @ gram) * B2))


def matrix_geometry(A, B_reference, B_candidate):
    """Exact Frobenius geometry of B@A using rank-sized Gram matrices."""
    _, B, gram = _factors(A, B_reference)
    _, C, _ = _factors(A, B_candidate)
    if C.shape != B.shape:
        raise ValueError('candidate shape differs from reference')
    nr2 = _weighted_dot(B, B, gram)
    nc2 = _weighted_dot(C, C, gram)
    if nr2 <= 1e-20 or nc2 <= 1e-20:
        raise ValueError('zero or degenerate weight-update norm')
    cosine = _weighted_dot(B, C, gram) / math.sqrt(nr2 * nc2)
    return {'reference_norm':math.sqrt(nr2), 'candidate_norm':math.sqrt(nc2),
            'relative_norm':math.sqrt(nc2 / nr2),
            'cosine':max(-1., min(1., float(cosine)))}


def build_orthogonal_output_factor(A, B, seed):
    """Seed a new B-space direction orthogonal under <B1@A,B2@A>_F."""
    _, B, gram = _factors(A, B)
    nb2 = _weighted_dot(B, B, gram)
    if nb2 <= 1e-20:
        raise ValueError('zero reference norm')
    rng = np.random.default_rng(int(seed))
    for _ in range(8):
        random_B = rng.standard_normal(B.shape)
        unit = random_B - (_weighted_dot(random_B, B, gram) / nb2) * B
        nu2 = _weighted_dot(unit, unit, gram)
        if np.isfinite(nu2) and nu2 > 1e-14 * nb2:
            unit *= math.sqrt(nb2 / nu2)
            g = matrix_geometry(A, B, unit)
            if abs(g['cosine']) < 1e-10 and abs(g['relative_norm'] - 1.) < 1e-10:
                return unit
    raise ValueError('could not construct independent nondegenerate orthogonal direction')


def rotate_output_factor(B, U, angle_deg):
    B = np.asarray(B, dtype=np.float64)
    U = np.asarray(U, dtype=np.float64)
    angle = float(angle_deg)
    if B.ndim != 2 or B.shape != U.shape or not np.isfinite(B).all() or not np.isfinite(U).all():
        raise ValueError('invalid rotation factors')
    if not np.isfinite(angle) or not 0 <= angle <= 180:
        raise ValueError('angle must be finite in [0,180] degrees')
    rad = np.deg2rad(angle)
    return np.cos(rad) * B + np.sin(rad) * U


