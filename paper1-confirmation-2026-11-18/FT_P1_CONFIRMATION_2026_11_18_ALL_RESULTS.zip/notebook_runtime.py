"""Executable notebook stages, assembled after the pinned original setup.

Special section markers delimit the notebook cells below. The first
archive runtime is intentionally NOT run: only its immutable setup cells.
"""

# %% NOTEBOOK_CELL 12 — freeze fresh questions and raw/padded prompt inputs
import csv, sys, gc

torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cudnn.allow_tf32=False
torch.set_float32_matmul_precision('highest')
assert BASE_HASH==ARCHIVE_PROTOCOL['fp32_base_weight_sha256']
check_frozen()
assert ARCHIVE_PROTOCOL['model_id']==MODEL_ID
assert ARCHIVE_PROTOCOL['model_revision']==MODEL_REV
assert ARCHIVE_PROTOCOL['checkpoint_sha256']=={k:v['sha256'] for k,v in ASSET_DATA.items()}

# These literal prompts are copied from the archived FT-CI-v2 executed source.
_REWORD={
 'generic':'Give a careful and concise response to the following question.\n\nQuestion: ',
 'math_format':'Work out this arithmetic word problem carefully and concisely. End with one line written exactly as: Final answer: <number>.\n\nQuestion: '
}
P1_VARIANTS={'original':{t:PROMPTS[t] for t in ('generic','math_format')},
             'reworded':_REWORD}
P1_VARIANT_NAMES=('original','reworded')
P1_TEMPLATE_NAMES=('generic','math_format')
P1_DIRECTIONS=('signed','rotated_90')

_archived_texts=json.loads((ARCHIVE_DIR/'FROZEN_CI_V2_QUESTION_TEXTS.json').read_text())
_archived_cohort=json.loads((ARCHIVE_DIR/'FROZEN_CI_V2_QUESTION_IDENTITIES.json').read_text())
_old_heldout=_archived_cohort['heldout']
assert len(_old_heldout)==32, 'Expected exactly the original 32 frozen heldout questions'
ORIGINAL_QUESTIONS=[dict(row,question=_archived_texts[row['hash']]) for row in _old_heldout]
for _row in ORIGINAL_QUESTIONS:
 assert sha(_row['question'])==_row['hash']

_all_prior=set(ARCHIVE_PROTOCOL['all_historical_exclusions'])
_all_prior.update(_archived_texts)
_additional=set(ADDITIONAL_EXCLUSION_HASHES)
assert all(len(x)==64 and all(c in '0123456789abcdef' for c in x) for x in _additional)
_all_prior.update(_additional)
_split_questions={}
for _split in ('test','train'):
 _split_questions[_split]=[str(it['question']).strip()
     for it in load_dataset('openai/gsm8k','main',split=_split)]
# The public GSM8K answer field is intentionally never accessed.
_n_fresh=2 if SMOKE_TEST else FRESH_QUESTION_COUNT
_selected=select_fresh_questions(_split_questions,_all_prior,_n_fresh,FRESH_COHORT_SALT)
FRESH_QUESTIONS=_selected['questions']
assert not ({r['hash'] for r in FRESH_QUESTIONS}&_all_prior)
assert len(set(r['hash'] for r in FRESH_QUESTIONS))==len(FRESH_QUESTIONS)
_frozen_questions={'selection':_selected,'source_split':_selected['source_split'],
 'excluded_archived_count':len(_all_prior)-len(_additional),
 'excluded_extra_hashes':sorted(_additional),
 'independence_caveat':'Disjoint from archived FT-CI-v2 prior history and supplied extra exclusions; later unpublished runs are not independently verifiable without their exclusion hashes.'}
_questions_path=RUN/'FROZEN_P1_CONFIRM_QUESTIONS.json'
if _questions_path.exists():
 assert json.loads(_questions_path.read_text())==_frozen_questions,'Cohort drift on resume'
else:atomic_json(_questions_path,_frozen_questions)
print('Selected fresh questions:',len(FRESH_QUESTIONS),'split',_selected['source_split'])

def _token_ids(content):
 return [int(t) for t in tok.apply_chat_template(
     [{'role':'user','content':content}],tokenize=True,add_generation_prompt=True)]

FRESH_INPUTS={}
MATCH_DIAGNOSTICS=[]
# Qwen chat-template messages begin with the same exact role header. Padding
# is inserted as explicit newline token IDs *after* that header, because BPE
# encoding of arbitrary text newlines need not visit every token count.
_empty_chat=[int(x) for x in tok.apply_chat_template(
    [{'role':'user','content':''}],tokenize=True,add_generation_prompt=True)]
assert END_ID in _empty_chat,'Expected Qwen <|im_end|> boundary'
_chat_header_ids=_empty_chat[:_empty_chat.index(END_ID)]
assert len(_chat_header_ids)>=3 and _chat_header_ids[0]==tok.convert_tokens_to_ids('<|im_start|>')
_newline_ids=[int(x) for x in tok.encode('\n',add_special_tokens=False)]
assert len(_newline_ids)==1,'Expected a single newline token to insert exactly'
_newline_id=_newline_ids[0]
assert tok.decode([_newline_id],skip_special_tokens=False,clean_up_tokenization_spaces=False)=='\n'
for _item in FRESH_QUESTIONS:
 _q=_item['question'];_id=_item['question_id']
 _prefixes={f'{v}|{t}':P1_VARIANTS[v][t]
   for v in P1_VARIANT_NAMES for t in P1_TEMPLATE_NAMES}
 _raw_inputs={k:_token_ids(p+_q) for k,p in _prefixes.items()}
 _matched=exact_token_count_matched(_raw_inputs,_chat_header_ids,
                                     _newline_id,max_padding=MATCH_MAX_PADDING_TOKENS)
 _lengths={}
 for _key,_p in _prefixes.items():
  _v,_t=_key.split('|')
  _raw=_raw_inputs[_key]
  FRESH_INPUTS[(_id,'fresh_raw',_v,_t)]=_raw
  FRESH_INPUTS[(_id,'fresh_matched',_v,_t)]=_matched[_key]['ids']
  _lengths[_key]={'raw_tokens':len(_raw),'matched_tokens':len(_matched[_key]['ids']),
                  'padding_tokens':_matched[_key]['padding_tokens'],
                  'matching_method':_matched[_key]['matching_method'],
                  'matched_input_sha256':sha(json.dumps(_matched[_key]['ids']))}
 assert len(set(x['matched_tokens'] for x in _lengths.values()))==1
 MATCH_DIAGNOSTICS.append({'question_id':_id,'hash':_item['hash'],
   'matched_token_count':next(iter(_lengths.values()))['matched_tokens'],
   'conditions':_lengths})

_diagnostics_path=RUN/'PROMPT_MATCH_DIAGNOSTICS.json'
if _diagnostics_path.exists():
 assert json.loads(_diagnostics_path.read_text())==MATCH_DIAGNOSTICS,'Tokenizer/prompt matching drift'
else:atomic_json(_diagnostics_path,MATCH_DIAGNOSTICS)

_environment={'python':sys.version.split()[0],'torch':torch.__version__,
 'transformers':__import__('transformers').__version__,
 'cuda':str(torch.version.cuda),'gpu':torch.cuda.get_device_name(0),
 'tf32':bool(torch.backends.cuda.matmul.allow_tf32),
 'model_revision':MODEL_REV,'fp32_base_hash':BASE_HASH}
_env_path=RUN/'ENVIRONMENT_P1_CONFIRM.json'
if _env_path.exists():
 assert json.loads(_env_path.read_text())==_environment,'Runtime drift; use a new RUN_NAME'
else:atomic_json(_env_path,_environment)

_protocol={
 'study':'FT_P1_INDEPENDENT_TOKEN_LENGTH_MATCHED_CONFIRMATION',
 'status':'SMOKE_NONINFERENTIAL' if SMOKE_TEST else 'PENDING',
 'model_id':MODEL_ID,'model_revision':MODEL_REV,'fp32_base_weight_sha256':BASE_HASH,
 'checkpoint_sha256':ARCHIVE_PROTOCOL['checkpoint_sha256'],
 'archive_protocol_sha256':sha_bytes((ARCHIVE_DIR/'LOCKED_CI_V2_PROTOCOL.json').read_bytes()),
 'archive_heldout_hashes':[r['hash'] for r in ORIGINAL_QUESTIONS],
 'fresh_hashes':[r['hash'] for r in FRESH_QUESTIONS],
 'fresh_split':_selected['source_split'],'fresh_question_count':len(FRESH_QUESTIONS),
 'fresh_cohort_salt':FRESH_COHORT_SALT,
 'all_historical_exclusion_hashes':sorted(_all_prior),
 'additional_exclusions':sorted(_additional),
 'templates':list(P1_TEMPLATE_NAMES),'variants':list(P1_VARIANT_NAMES),
 'directions':list(P1_DIRECTIONS),'prompt_texts':P1_VARIANTS,
 'matched_prompt_diagnostics_sha256':sha_bytes(_diagnostics_path.read_bytes()),
 'matching_algorithm':'Explicit single-newline TOKEN ID padding immediately after chat role header; preserves original token sequence afterward; may be noncanonical BPE and NOT semantically neutral.',
 'bootstrap_seed':20261118,'bootstrap_repetitions':10000,
 'primary_min_mean':0.10,'primary_ci95_lower_gt':0.0,
 'numerical_thresholds':{'tangent_convergence_max':0.03,
   'tangent_signal_to_baseline_repeat_min':20,
   'block19_attenuation_abs_max':0.005,'block19_cosine_min':0.995},
 'finite_diff_steps':[.01,.005],
 'sample_replay_tolerance':REPLAY_TOLERANCE,
 'smoke_noninferential':SMOKE_TEST,
 'prior_selection':'Original-vs-reworded math_format-minus-generic contrast was exploratory in prior work; this is within-model confirmation.',
 'training':False,'gold_answers_used':False,
 'archive_replay_scope':'Only 2 variants x 2 templates x signed x 32 questions, not the original full 1024-cell grid.',
 'independence_caveat':_frozen_questions['independence_caveat'],
 'environment':_environment,
 'confirmation_core_sha256':sha(FT_CONFIRMATION_CORE_SOURCE)}
PROTOCOL_PATH=RUN/'LOCKED_P1_CONFIRMATION_PROTOCOL.json'
if PROTOCOL_PATH.exists():
 assert json.loads(PROTOCOL_PATH.read_text())==_protocol,'Protocol changed; choose new RUN_NAME'
else:atomic_json(PROTOCOL_PATH,_protocol)
P1_PROTOCOL_SHA=sha_bytes(PROTOCOL_PATH.read_bytes())
print('Frozen protocol SHA256:',P1_PROTOCOL_SHA)

# %% NOTEBOOK_CELL 13 — exact frozen editor and last-token numeric measurements
assert 'HOOK' in globals()
HOOK.remove() # Prevent stacking the original notebook's adapter and the new edit.

def _effective_frob(editor):
 _raw=float(editor.delta_weight_norm(editor.gates(None)).item())
 return min(_raw,float(W_NORM)*float(MAX_EDIT_NORM_RATIO))

A=static.A.detach().cpu().numpy().astype(np.float64)
B=static.B.detach().cpu().numpy().astype(np.float64)
_orth=build_orthogonal_output_factor(A,B,ROTATION_SEED)
_rot_B=rotate_output_factor(B,_orth,90)
_rotation_geometry=matrix_geometry(A,B,_rot_B)
assert abs(_rotation_geometry['cosine'])<1e-8
assert abs(_rotation_geometry['relative_norm']-1.)<1e-8
rotated=RankEditor(False).to(DEVICE)
with torch.no_grad():
 rotated.A.copy_(static.A)
 rotated.B.copy_(torch.as_tensor(_rot_B,dtype=torch.float32,device=DEVICE))
rotated.eval()
for _param in rotated.parameters():_param.requires_grad_(False)
assert abs(_effective_frob(rotated)-_effective_frob(static))<1e-4
assert abs(_effective_frob(static)-CI_V1_EFFECTIVE_FROB)<1e-4
EDITORS={'signed':static,'rotated_90':rotated}
atomic_json(RUN/'P1_ROTATED_CONTROL_GEOMETRY.json',_rotation_geometry)

_active_editor=None
_active_strength=0.0
_last_local_edit=None
_last_block19=None

def _injection_hook(module,inputs,output):
 global _last_local_edit
 if _active_editor is None:return output
 _delta=_active_editor(inputs[0],None,W_NORM,MAX_EDIT_NORM_RATIO).to(output.dtype)
 _last_local_edit=float(_delta[0,-1].float().norm().item())
 return output+_active_strength*_delta

def _block19_hook(module,inputs,output):
 global _last_block19
 _tensor=output[0] if isinstance(output,(tuple,list)) else output
 _last_block19=_tensor[0,-1].detach().float().cpu().numpy().astype(np.float64)

P1_INJECTION_HOOK=proj.register_forward_hook(_injection_hook)
P1_BLOCK19_HOOK=model.model.layers[19].register_forward_hook(_block19_hook)

@torch.inference_mode()
def _trace_logits(ids,editor=None,strength=0.):
 global _active_editor,_active_strength,_last_local_edit,_last_block19
 assert _active_editor is None,'Nested interventions not allowed'
 _active_editor,_active_strength=editor,float(strength)
 _last_local_edit,_last_block19=None,None
 _ids=torch.tensor([ids],dtype=torch.long,device=DEVICE)
 try:
  _out=model(input_ids=_ids,use_cache=False)
  _logits=_out.logits[0,-1,:].detach().float().cpu().numpy().astype(np.float64)
  _block=_last_block19
  _local=_last_local_edit
 finally:
  _active_editor,_active_strength=None,0.
 assert _block is not None and np.isfinite(_block).all()
 assert np.isfinite(_logits).all()
 del _out,_ids
 return {'logits':_logits,'block19':_block},_local

def _trace_difference(a,b):
 return {key:a[key]-b[key] for key in ('logits','block19')}

def _measure_case(question,direction,variant,template,stage):
 if stage=='original_replay':
  ids=_token_ids(P1_VARIANTS[variant][template]+question['question'])
 else:
  ids=FRESH_INPUTS[(question['question_id'],stage,variant,template)]
 editor=EDITORS[direction]
 baseline,_=_trace_logits(ids)
 repeated,_=_trace_logits(ids)
 _derivatives={}
 _local=None
 for step in (.01,.005):
  plus,_local_value=_trace_logits(ids,editor,+step)
  minus,_=_trace_logits(ids,editor,-step)
  _derivatives[step]={k:(plus[k]-minus[k])/(2*step) for k in baseline}
  if step==.005:_local=_local_value
 full,_=_trace_logits(ids,editor,1.)
 assert _local is not None and _local>0,'Frozen edit was not applied'
 _deriv=_derivatives[.005]
 _metrics=response_metrics(_deriv['logits'],full['logits']-baseline['logits'],1.)
 _block_metrics=response_metrics(_deriv['block19'],full['block19']-baseline['block19'],1.)
 _tn=float(np.linalg.norm(_deriv['logits']))
 _repeat=float(np.linalg.norm(repeated['logits']-baseline['logits']))
 _converge=float(np.linalg.norm(_derivatives[.005]['logits']-_derivatives[.01]['logits'])/max(_tn,1e-30))
 _quality_flags=[]
 if _converge>.03:_quality_flags.append('finite_difference_nonconverged')
 if .005*_tn<=20*_repeat:_quality_flags.append('baseline_jitter_dominates')
 if abs(_block_metrics['attenuation'])>.005 or _block_metrics['cosine_to_tangent']<.995:
  _quality_flags.append('nonlinear_at_target_layer')
 return {'question_id':question['question_id'],'hash':question['hash'],
   'direction':direction,'variant':variant,'template':template,'stage':stage,
   'record_key':'|'.join((stage,question['hash'],direction,variant,template)),
   'protocol_sha256':P1_PROTOCOL_SHA,'prompt_tokens':len(ids),
   'full_attenuation':_metrics['attenuation'],'full_cosine':_metrics['cosine_to_tangent'],
   'full_displacement_l2':_metrics['response_l2'],
   'logit_tangent_l2':_metrics['tangent_norm'],
   'relative_linear_error':_metrics['relative_linear_error'],
   'tangent_convergence':_converge,'baseline_repeat_l2':_repeat,
   'block19_attenuation':_block_metrics['attenuation'],
   'block19_cosine':_block_metrics['cosine_to_tangent'],
   'last_token_edit_l2':float(_local),'effective_edit_frob':_effective_frob(editor),
   'numeric_quality_flags':_quality_flags}

# %% NOTEBOOK_CELL 14 — checkpoint each real GPU measurement and resume safely
STAGES=(('original_replay',ORIGINAL_QUESTIONS[:2] if SMOKE_TEST else ORIGINAL_QUESTIONS,('signed',)),
        ('fresh_matched',FRESH_QUESTIONS,P1_DIRECTIONS),
        ('fresh_raw',FRESH_QUESTIONS,P1_DIRECTIONS))
_rows_path=RUN/'P1_RESPONSE_GEOMETRY.jsonl'
ALL_ROWS=verified_jsonl(_rows_path,P1_PROTOCOL_SHA)
_expected_keys=set()
_task_total=0
for _stage,_questions,_directions in STAGES:
 for _item in _questions:
  for _direction in _directions:
   for _variant in P1_VARIANT_NAMES:
    for _template in P1_TEMPLATE_NAMES:
     _expected_keys.add('|'.join((_stage,_item['hash'],_direction,_variant,_template)))
_task_total=len(_expected_keys)
assert set(ALL_ROWS).issubset(_expected_keys),'Unexpected saved scientific rows'
print('Total frozen cells:',_task_total,'already completed:',len(ALL_ROWS))
_done=len(ALL_ROWS)
for _stage,_questions,_directions in STAGES:
 for _item in _questions:
  for _direction in _directions:
   for _variant in P1_VARIANT_NAMES:
    for _template in P1_TEMPLATE_NAMES:
     _key='|'.join((_stage,_item['hash'],_direction,_variant,_template))
     if _key in ALL_ROWS:continue
     try:
      _result=_measure_case(_item,_direction,_variant,_template,_stage)
      assert _result['record_key']==_key
      append_jsonl(_rows_path,_result)
      ALL_ROWS[_key]=_result
      _done+=1
      if _done%8==0 or _done==_task_total:
       print(f'Progress {_done}/{_task_total} ({_stage}); Drive checkpoint saved',flush=True)
     except Exception as err:
      atomic_json(RUN/'LAST_STOP_DIAGNOSTIC.json',
                  {'cell':_key,'completed':_done,'total':_task_total,
                   'error_type':type(err).__name__,'error':str(err),
                   'traceback':traceback.format_exc()})
      _partial_zip=RUN.parent/(RUN_NAME+'_PARTIAL_RESULTS.zip')
      export_checked_zip(RUN,_partial_zip)
      print('Incomplete run: share this partial ZIP for troubleshooting:',_partial_zip)
      raise
assert len(ALL_ROWS)==_task_total,'Incomplete results; restart and Run all to resume'
check_frozen()
print('GPU measurements complete:',_done)

# %% NOTEBOOK_CELL 15 — audit every number; question-level bootstrap and plots
import matplotlib.pyplot as plt

_rows=list(ALL_ROWS.values())
_analyzed={}
_pairs={}
for _stage,_questions,_directions in STAGES:
 _srows=[r for r in _rows if r['stage']==_stage]
 ensure_complete_grid(_srows,[q['question_id'] for q in _questions],_directions,
                      P1_VARIANT_NAMES,P1_TEMPLATE_NAMES,_stage)
 for _direction in _directions:
  _subset=[r for r in _srows if r['direction']==_direction]
  _paired=paired_question_contrasts(_subset)
  _pairs[(_stage,_direction)]=_paired
  _analyzed.setdefault(_stage,{})[_direction]=bootstrap_mean(
    [p['contrast'] for p in _paired],reps=10000,seed=20261118)

_quality_bad=[{'record_key':r['record_key'],'flags':r['numeric_quality_flags']}
              for r in _rows if r['numeric_quality_flags']]
_ready=len(ALL_ROWS)==_task_total

# Compare only the identical archived 32x2x2 signed cells, never the entire prior grid.
with (ARCHIVE_DIR/'CI_V2_RAW_RESPONSE_GEOMETRY.csv').open(newline='') as _file:
 _raw_reference=list(csv.DictReader(_file))
_replay_rows=[r for r in _rows if r['stage']=='original_replay']
_replay_ids={r['question_id'] for r in _replay_rows}
_reference=[{'question_id':r['question_id'],'direction':r['direction'],
             'variant':r['variant'],'template':r['template'],
             'full_attenuation':float(r['attenuation'])}
           for r in _raw_reference if r['question_id'] in _replay_ids
           and r['direction']=='signed' and r['variant'] in P1_VARIANT_NAMES
           and r['template'] in P1_TEMPLATE_NAMES]
_replay=compare_replay(_replay_rows,_reference,tolerance=REPLAY_TOLERANCE)
_numerical_ok=len(_quality_bad)==0 and _replay['status']=='MATCH'
_primary=_analyzed['fresh_matched']['signed']
_decision=inferential_decision(_primary,_numerical_ok,_ready,SMOKE_TEST)
_control_diffs={p['question_id']:p['contrast'] for p in _pairs['fresh_matched','rotated_90']}
_control_pairs=[p['contrast']-_control_diffs[p['question_id']]
                for p in _pairs['fresh_matched','signed']]
_control=bootstrap_mean(_control_pairs,reps=10000,seed=20261118)
_raw_vs_matched={p['question_id']:p['contrast'] for p in _pairs['fresh_raw','signed']}
_matching_differences=[p['contrast']-_raw_vs_matched[p['question_id']]
 for p in _pairs['fresh_matched','signed']]
_matching_comparison=bootstrap_mean(_matching_differences,reps=10000,seed=20261118)

SUMMARY={'status':_decision['status'],'decision':_decision,
 'n_measured_cells':len(_rows),'frozen_expected_cells':_task_total,
 'primary_fresh_matched_signed':_primary,'by_stage_and_direction':_analyzed,
 'signed_minus_rotated90_control':_control,
 'matched_minus_raw_signed':_matching_comparison,
 'numeric_quality':{'all_cells_pass':_numerical_ok,'invalid_count':len(_quality_bad),
                    'invalid_cells':_quality_bad,
                    'replay_required_to_match':True},
 'original_replay':_replay,
 'study_limits':['One pinned pretrained model and one frozen edit direction.',
  'Measure is last-token logit attenuation, not task correctness.',
  'Explicit newline-token padding is a formatting change and may form noncanonical BPE token sequences; it is not invisible or semantically neutral.',
  'GSM8K train samples, if selected, might have been included in model pretraining.',
  'Additional studies after the archived FT-CI-v2 registry require explicit exclusion hashes.',
  'A failed replay or numerical checks limits the scientific interpretation.'],
 'provenance':{'locked_protocol_sha256':P1_PROTOCOL_SHA,'model_revision':MODEL_REV,
              'base_weight_sha256':BASE_HASH,'archive_record':'https://zenodo.org/records/24284827'}}
atomic_json(RUN/'P1_CONFIRMATION_SUMMARY.json',SUMMARY)
atomic_json(RUN/'P1_QUESTION_LEVEL_CONTRASTS.json',
   {stage:{d:_pairs[stage,d] for d in dirs}
    for stage,qs,dirs in STAGES})

_signed=_pairs['fresh_matched','signed']
_raw_by_q=_raw_vs_matched
fig,ax=plt.subplots(1,2,figsize=(12,4.8))
ax[0].scatter(range(len(_signed)),[p['contrast'] for p in _signed],s=17,alpha=.8)
ax[0].axhline(0,color='gray',linewidth=1);ax[0].axhline(.1,color='purple',linestyle='--',label='Predeclared mean cutoff')
ax[0].set(title='Matched prompts: signed-edit question contrasts',xlabel='Frozen question index',ylabel='Attenuation contrast')
ax[0].legend()
ax[1].scatter([_raw_by_q[p['question_id']] for p in _signed],
              [p['contrast'] for p in _signed],s=20,alpha=.7)
ax[1].axhline(0,color='gray',linewidth=1)
ax[1].axvline(0,color='gray',linewidth=1)
ax[1].set(title='Prompt-length control: same questions',xlabel='Raw-prompt contrast',ylabel='Matched-prompt contrast')
fig.tight_layout();fig.savefig(RUN/'P1_MATCHED_VS_RAW.png',dpi=190);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4.8))
_labels=[];_means=[];_low=[];_high=[]
for _stage,_direction in [('original_replay','signed'),('fresh_raw','signed'),
                          ('fresh_matched','signed'),('fresh_matched','rotated_90')]:
 _stat=_analyzed[_stage][_direction]
 _labels.append(_stage.replace('fresh_','')+' / '+_direction)
 _means.append(_stat['mean']);_low.append(_stat['mean']-_stat['ci95'][0]);_high.append(_stat['ci95'][1]-_stat['mean'])
ax.errorbar(range(len(_labels)),_means,yerr=[_low,_high],fmt='o',capsize=4,color='teal')
ax.axhline(0,color='gray',linewidth=1);ax.axhline(.1,color='purple',linestyle='--')
ax.set_xticks(range(len(_labels)),_labels,rotation=20,ha='right')
ax.set(title='Question-bootstrap means and 95% intervals',ylabel='Signed prompt interaction in logit attenuation')
fig.tight_layout();fig.savefig(RUN/'P1_CONDITION_CONTRASTS.png',dpi=190);plt.close(fig)

_status=SUMMARY['status']
_lines=['# Paper 1 Confirmation — Research Results','',f'**Status: {_status}**','',
 f'GPU cells completed: {len(_rows)} / {_task_total}',
 f"Original archive replay: {_replay['status']} (max absolute error: {_replay.get('max_abs_error','n/a')})",
 f"Matched new-question primary contrast: mean {_primary['mean']:.6f}; 95% cluster bootstrap {_primary['ci95']}",
 f"Matched signed-minus-orthogonal-control contrast: mean {_control['mean']:.6f}; 95% cluster bootstrap {_control['ci95']}",
 f"Matched-minus-raw paired contrast: mean {_matching_comparison['mean']:.6f}; 95% cluster bootstrap {_matching_comparison['ci95']}",
 f'Numerical invalid cells: {len(_quality_bad)}','',
 '## What this does and does not show','',
 'The primary response measurement is the reduction or increase in the norm of the final-token logits when a fixed edit is applied at strength 1.0 compared with its local tangent at strength 0.',
 'This is *not* a mathematical-answer accuracy result and does not show the model has learned or repaired reasoning.',
 'All statistical intervals resample *questions*, preserving the four prompts for each question.',
 'Explicit newline tokens after the role header equalize lengths but can alter attention and prompt interpretation; they are not semantically neutral, and may be noncanonical BPE text encodings.',
 'Because only historical exclusions in the archived v2 protocol are known, a user with later unpublished experiment cohorts should supply their question hashes and rerun before calling this fully independent.',
 '', '## Files', '',
 '`P1_RESPONSE_GEOMETRY.jsonl` contains every raw recorded response; `LOCKED_P1_CONFIRMATION_PROTOCOL.json` fixes identities and configuration; plots are illustrative, not tests.',
 '`P1_CONFIRMATION_SUMMARY.json` is the machine-readable result; `CHECKSUMS_SHA256.json` in ZIP lists all SHA256 digests.',
 'Reproduce or audit this notebook before changing the published article or making external scientific claims.', '']
(RUN/'README_RESULTS.md').write_text('\n'.join(_lines),encoding='utf-8')
print('Analysis:',SUMMARY['status'],'Replay:',_replay['status'],
      'numeric-invalid:',len(_quality_bad),'matched-primary:',_primary)

# %% NOTEBOOK_CELL 16 — immutable ZIP bundle saved to Drive and downloaded
_zip_path=RUN.parent/(RUN_NAME+'_ALL_RESULTS.zip')
_manifest=export_checked_zip(RUN,_zip_path)
print('ZIP READY:',_zip_path,'files:',len(_manifest['files']),
      'bytes:',_zip_path.stat().st_size)
if AUTO_DOWNLOAD_RESULTS:
 try:
  from google.colab import files
  files.download(str(_zip_path))
 except Exception as _download_err:
  print('Browser download was unavailable. Retrieve this ZIP from Google Drive:',_zip_path,
        'reason:',str(_download_err))
print('Return the single ZIP above for independent result analysis and paper-update decisions.')
