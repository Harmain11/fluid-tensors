# Paper 1 Confirmation — Research Results

**Status: MATCHED_PATTERN_CONFIRMED**

GPU cells completed: 1152 / 1152
Original archive replay: MATCH (max absolute error: 0.0)
Matched new-question primary contrast: mean 0.193491; 95% cluster bootstrap [0.16689611383364772, 0.21900205593789496]
Matched signed-minus-orthogonal-control contrast: mean 0.189431; 95% cluster bootstrap [0.16204118367751788, 0.21650565613096256]
Matched-minus-raw paired contrast: mean -0.035755; 95% cluster bootstrap [-0.0485988927175284, -0.023462161209359515]
Numerical invalid cells: 0

## What this does and does not show

The primary response measurement is the reduction or increase in the norm of the final-token logits when a fixed edit is applied at strength 1.0 compared with its local tangent at strength 0.
This is *not* a mathematical-answer accuracy result and does not show the model has learned or repaired reasoning.
All statistical intervals resample *questions*, preserving the four prompts for each question.
Explicit newline tokens after the role header equalize lengths but can alter attention and prompt interpretation; they are not semantically neutral, and may be noncanonical BPE text encodings.
Because only historical exclusions in the archived v2 protocol are known, a user with later unpublished experiment cohorts should supply their question hashes and rerun before calling this fully independent.

## Files

`P1_RESPONSE_GEOMETRY.jsonl` contains every raw recorded response; `LOCKED_P1_CONFIRMATION_PROTOCOL.json` fixes identities and configuration; plots are illustrative, not tests.
`P1_CONFIRMATION_SUMMARY.json` is the machine-readable result; `CHECKSUMS_SHA256.json` in ZIP lists all SHA256 digests.
Reproduce or audit this notebook before changing the published article or making external scientific claims.
