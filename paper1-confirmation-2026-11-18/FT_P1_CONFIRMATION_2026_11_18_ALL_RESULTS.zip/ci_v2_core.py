"""Dependency-light, preregistered FT-CI-v2 paired response analysis.

One question is the resampling unit. All direction/variant/template cells from
that question are kept together. Analysis is intentionally separate from GPU
instrumentation so artifact audits can recalculate it offline.
"""

from __future__ import annotations

import math
import hashlib
import numpy as np


VARIANTS = ('original', 'reworded', 'formal', 'terse')
DIRECTIONS = ('signed', 'rotated_90')
TEMPLATES = ('generic', 'math_only', 'format_only', 'math_format')


def select_fresh_question_cohort(test_lookup, train_lookup, exclusions, count, salt):
    """Choose one split, never a mixed cohort or a previously used question.

    Exhausting the GSM8K test split is a dataset-capacity issue, not evidence
    about an effect. The train split is a disclosed alternative data source;
    its different model-exposure status must be noted in the paper.
    """
    if count < 1 or not isinstance(salt, str) or not salt:
        raise ValueError('Invalid frozen selection parameters')
    old = set(exclusions)
    candidates={split:sorted((h for h in lookup if h not in old),
        key=lambda h:hashlib.sha256((salt+'/'+h).encode('utf-8')).hexdigest())
        for split,lookup in (('test',test_lookup),('train',train_lookup))}
    eligible_counts={name:len(items) for name,items in candidates.items()}
    chosen='test' if eligible_counts['test']>=count else 'train'
    if eligible_counts[chosen]<count:
        raise ValueError('Both GSM8K splits have insufficient unused question identities: '+
                         str(eligible_counts))
    return {'source_split':chosen,'hashes':candidates[chosen][:count],
            'eligible_counts':eligible_counts}


def response_metrics(tangent, response, strength):
    t = np.asarray(tangent, dtype=np.float64)
    r = np.asarray(response, dtype=np.float64)
    s = float(strength)
    if t.ndim != 1 or t.size == 0 or r.shape != t.shape:
        raise ValueError('Response and tangent must be equally sized vectors')
    if not np.isfinite(t).all() or not np.isfinite(r).all() or not math.isfinite(s) or s <= 0:
        raise ValueError('Nonfinite response or invalid strength')
    tn, rn = float(np.linalg.norm(t)), float(np.linalg.norm(r))
    if tn <= 1e-20 or rn <= 1e-20:
        raise ValueError('Degenerate local derivative or displacement')
    cosine = float(np.clip(np.dot(t, r) / (tn * rn), -1., 1.))
    return {'tangent_norm': tn, 'response_l2': rn,
            'attenuation': 1. - rn / (s * tn), 'cosine_to_tangent': cosine,
            'relative_linear_error': float(np.linalg.norm(r - s*t) / (s*tn))}


def _finite(row, name):
    value = float(row[name])
    if not math.isfinite(value):
        raise ValueError(f'Nonfinite {name}')
    return value


def _ci(values, sample_idx):
    arr = np.asarray(values, dtype=np.float64)
    if not np.isfinite(arr).all():
        raise ValueError('Nonfinite statistical input')
    boots = arr[sample_idx].mean(axis=1)
    return {'mean': float(arr.mean()),
            'ci95': [float(v) for v in np.quantile(boots, (.025, .975))]}


def _quality(row):
    invalid = []
    converge = _finite(row, 'tangent_convergence')
    repeat = _finite(row, 'baseline_repeat_l2')
    tangent = _finite(row, 'logit_tangent_l2')
    displacement = _finite(row, 'full_displacement_l2')
    attenuation = _finite(row, 'full_attenuation')
    cosine = _finite(row, 'full_cosine')
    b19_att = _finite(row, 'block19_attenuation')
    b19_cos = _finite(row, 'block19_cosine')
    if tangent <= 0 or displacement <= 0 or repeat < 0 or converge < 0:
        raise ValueError('Invalid norm or convergence')
    if not (0 <= int(row['prompt_tokens']) and abs(cosine) <= 1.00000001):
        raise ValueError('Invalid prompt length or cosine')
    if not math.isclose(attenuation, 1.-displacement/tangent, rel_tol=1e-5, abs_tol=1e-5):
        raise ValueError('Attenuation differs from measured raw norm')
    if converge > .03 or .005*tangent <= 20.*repeat:
        invalid.append('logit_tangent_signal')
    if abs(b19_att) > .005 or b19_cos < .995:
        invalid.append('nonlinear_layer19_edit')
    return invalid


def score_conditions(rows, *, expected_questions=32, bootstrap_iterations=10000,
                     seed=20261130, min_effect=.10, smoke=False):
    """Analyze a complete 2 directions x 4 paraphrases x 4 prompts factorial grid."""
    if not isinstance(expected_questions, int) or expected_questions < 1:
        raise ValueError('Invalid number of question clusters')
    if bootstrap_iterations < 100 or not math.isfinite(min_effect) or min_effect < 0:
        raise ValueError('Invalid bootstrap configuration')
    table, hashes, failed, protocol = {}, {}, {}, None
    for row in rows:
        q, d, v, t = (row[k] for k in ('question_id', 'direction', 'variant', 'template'))
        if d not in DIRECTIONS or v not in VARIANTS or t not in TEMPLATES or not q:
            raise ValueError('Unexpected factorial identity')
        key = (q, d, v, t)
        if key in table:
            raise ValueError('Duplicate factorial cell')
        if q in hashes and hashes[q] != row['hash']:
            raise ValueError('Question hash changes between cells')
        hashes[q] = row['hash']
        if protocol is None:
            protocol = row['protocol_sha256']
        if row['protocol_sha256'] != protocol or not isinstance(protocol, str) or len(protocol) != 64:
            raise ValueError('Protocol drift within factorial grid')
        table[key] = row
        flags = _quality(row)
        if flags:
            failed['|'.join(key)] = flags
    questions = sorted(hashes)
    if len(questions) != expected_questions or len(table) != expected_questions*len(DIRECTIONS)*len(VARIANTS)*len(TEMPLATES):
        raise ValueError('Incomplete factorial table')
    for q in questions:
        for d in DIRECTIONS:
            for v in VARIANTS:
                for t in TEMPLATES:
                    if (q, d, v, t) not in table:
                        raise ValueError('Missing factorial cell')
    idx = np.random.default_rng(seed).integers(0, len(questions),
                                                size=(bootstrap_iterations,len(questions)))
    def a(q, d, v, t):
        return float(table[q,d,v,t]['full_attenuation'])
    def mf(q,d,v):
        return a(q,d,v,'math_format')-a(q,d,v,'generic')
    def interaction(q,d,v):
        return (a(q,d,v,'math_format')-a(q,d,v,'math_only')-
                a(q,d,v,'format_only')+a(q,d,v,'generic'))
    variants = {}
    for v in VARIANTS:
        variants[v] = {}
        for d in DIRECTIONS:
            variants[v][d] = {
                'mf_vs_generic': _ci([mf(q,d,v) for q in questions],idx),
                'factorial_interaction': _ci([interaction(q,d,v) for q in questions],idx),
                'cell_means': {t: float(np.mean([a(q,d,v,t) for q in questions]))
                               for t in TEMPLATES},
                'mean_prompt_tokens': {t: float(np.mean([
                    table[q,d,v,t]['prompt_tokens'] for q in questions])) for t in TEMPLATES}}
    diffs = [mf(q,'signed','original')-mf(q,'signed','reworded') for q in questions]
    primary = _ci(diffs,idx)
    rotated_diffs = [mf(q,'rotated_90','original')-
                     mf(q,'rotated_90','reworded') for q in questions]
    rotation = _ci([x-y for x,y in zip(diffs,rotated_diffs)],idx)
    numerical_gate = {'invalid_count': len(failed), 'invalid_reasons': failed,
                      'row_count': len(rows), 'question_clusters': len(questions)}
    replicated = primary['mean'] >= min_effect and primary['ci95'][0] > 0
    status = ('SMOKE_NONINFERENTIAL' if smoke else
              'NUMERIC_INCONCLUSIVE' if failed else
              'PRIMARY_REPLICATED_WITHIN_MODEL' if replicated else
              'PRIMARY_NOT_REPLICATED')
    return {'study':'FT_CI_V2_PROMPT_CONDITIONED_RESPONSE', 'status':status,
            'primary':{'original_minus_reworded_mf_vs_generic':primary,
                       'effect_cutoff':min_effect,
                       'note':'Previously exploratory CI-v1 contrast; independent new questions, same model.'},
            'variants':variants,
            'direction_control':{'signed_minus_rotated_prompt_gap':rotation},
            'numerical_gate':numerical_gate,
            'bootstrap_iterations':bootstrap_iterations,
            'smoke':bool(smoke)}


def score_patch_effects(rows, *, expected_questions=32, bootstrap_iterations=10000,
                        seed=20261201, smoke=False,
                        modes=('unpatched','sham20','linear_block20','linear_attn20',
                               'linear_mlp20','linear_q20','linear_k20','linear_v20',
                               'linear_o20','random_attn20_a','random_attn20_b',
                               'random_block20_a','random_block20_b')):
    """Exploratory factorial sensitivity; no unique-mechanism causal claim."""
    if bootstrap_iterations < 100 or 'unpatched' not in modes or \
            'linear_attn20' not in modes or 'linear_mlp20' not in modes:
        raise ValueError('Invalid patch analysis modes')
    table, hashes, failed, protocol = {}, {}, {}, None
    for row in rows:
        q,v,t,d = (row[k] for k in ('question_id','variant','template','direction'))
        key=(q,v,t)
        if d!='signed' or v not in ('original','reworded') or t not in TEMPLATES:
            raise ValueError('Invalid focused patch identity')
        if key in table or (q in hashes and hashes[q]!=row['hash']):
            raise ValueError('Duplicate cell or changing question identity')
        hashes[q]=row['hash']
        if protocol is None:protocol=row['protocol_sha256']
        if protocol!=row['protocol_sha256'] or not isinstance(protocol,str) or len(protocol)!=64:
            raise ValueError('Patch protocol mismatch')
        if set(row['modes'])!=set(modes):
            raise ValueError('Incomplete patch-mode grid')
        for mode in modes:
            x=float(row['modes'][mode]['attenuation'])
            if not math.isfinite(x):raise ValueError('Nonfinite patch attenuation')
        reasons=[]
        for name,value in row['patch_diagnostics'].items():
            f=float(value)
            if not math.isfinite(f) or f < 0:raise ValueError('Invalid patch diagnostic')
            if (name=='sham_relative_l2' and f>.001 or
                 name.endswith('_distance_relative_error') and f>.01 or
                 name.endswith('_target_relative_error') and f>.01):
                reasons.append(name)
        if 'sham_relative_l2' not in row['patch_diagnostics']:
            raise ValueError('Missing patch sham diagnostic')
        if reasons:failed['|'.join(key)]=reasons
        table[key]=row
    qids=sorted(hashes)
    if len(qids)!=expected_questions or len(table)!=expected_questions*2*len(TEMPLATES):
        raise ValueError('Incomplete patch factorial grid')
    for q in qids:
        for variant in ('original','reworded'):
            for template in TEMPLATES:
                if (q,variant,template) not in table:raise ValueError('Missing patch cell')
    idx=np.random.default_rng(seed).integers(0,len(qids),size=(bootstrap_iterations,len(qids)))
    def att(q,v,t,m):return float(table[q,v,t]['modes'][m]['attenuation'])
    def interaction(q,v,m):
        return (att(q,v,'math_format',m)-att(q,v,'math_only',m)-
                att(q,v,'format_only',m)+att(q,v,'generic',m))
    reduction={}
    for v in ('original','reworded'):
        reduction[v]={}
        for mode in modes:
            reduction[v][mode]=_ci([interaction(q,v,'unpatched')-
                                      interaction(q,v,mode) for q in qids],idx)
    attention_vs_mlp={v:_ci([interaction(q,v,'linear_mlp20')-
                                interaction(q,v,'linear_attn20') for q in qids],idx)
                      for v in ('original','reworded')}
    prompt_conditioned_adv=_ci([
        (interaction(q,'reworded','linear_mlp20')-
         interaction(q,'reworded','linear_attn20'))-
        (interaction(q,'original','linear_mlp20')-
         interaction(q,'original','linear_attn20')) for q in qids],idx)
    return {'study':'FT_CI_V2_EXPLORATORY_PATH_SENSITIVITY',
            'status':('SMOKE_NONINFERENTIAL' if smoke else
                      'NUMERIC_INCONCLUSIVE' if failed else 'EXPLORATORY_ONLY'),
            'interaction_reductions':reduction,
            'attention_vs_mlp':attention_vs_mlp,
            'prompt_conditioned_attention_advantage':prompt_conditioned_adv,
            'numerical_gate':{'invalid_count':len(failed),
                              'invalid_reasons':failed,'row_count':len(rows)},
            'bootstrap_iterations':bootstrap_iterations,'smoke':bool(smoke),
            'caution':'Last-token off-manifold patch sensitivity; not isolated circuits or world-first novelty.'}


def cross_stage_consistency(full_rows, patch_rows, *, tolerance=.002):
    """Identify drift between duplicate unpatched forward measurements."""
    table={(r['hash'],r['direction'],r['variant'],r['template']):
           float(r['full_attenuation']) for r in full_rows}
    errors=[]
    for row in patch_rows:
        key=(row['hash'],row['direction'],row['variant'],row['template'])
        if key not in table:
            errors.append({'key':key,'problem':'missing_matching_full_row'})
            continue
        a=float(row['modes']['unpatched']['attenuation'])
        if not math.isfinite(a) or abs(a-table[key])>tolerance:
            errors.append({'key':key,'problem':'unpatched_response_mismatch',
                           'full':table[key],'patch':a})
    return errors
