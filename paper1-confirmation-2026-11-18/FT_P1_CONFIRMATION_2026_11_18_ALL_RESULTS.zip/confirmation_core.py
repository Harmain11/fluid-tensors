"""Pure validation and analysis for Fluid Tensors Paper 1 confirmation.

No training, downloaded model, hidden gold answers, or external services.
Re-used literally inside the self-contained Colab notebook.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import zipfile

import numpy as np


def sha_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def select_fresh_questions(splits, excluded, count: int, salt: str):
    """Freeze a deterministic single-split cohort unseen by recorded experiments."""
    if count < 1 or not salt or not isinstance(excluded, (set, frozenset)):
        raise ValueError("Invalid frozen cohort configuration")
    eligible = {}
    counts = {}
    for split in ("test", "train"):
        records = {}
        for question in splits[split]:
            question = str(question).strip()
            digest = sha_text(question)
            if digest in records:
                raise ValueError(f"Duplicate question identity in {split}")
            records[digest] = question
        eligible[split] = {h: q for h, q in records.items() if h not in excluded}
        counts[split] = len(eligible[split])
    selected_split = "test" if counts["test"] >= count else "train"
    if counts[selected_split] < count:
        raise ValueError(f"Insufficient fresh questions: {counts}")
    ordered = sorted(eligible[selected_split], key=lambda h: sha_text(salt + "/" + h))[:count]
    questions = [
        {"question_id": "gsm_" + h[:16], "hash": h, "question": eligible[selected_split][h],
         "source_split": selected_split}
        for h in ordered
    ]
    return {"source_split": selected_split, "eligible_counts": counts, "questions": questions}


def exact_length_matched(tokenize, prefixes: dict, question: str, max_padding: int = 128):
    """Match exact model input lengths using prefix newlines; never rewrite question.

    This is a length/position control, not evidence of semantically neutral filler.
    `tokenize` must include the same chat template used for the model run.
    """
    if not prefixes or max_padding < 0:
        raise ValueError("Invalid matching specification")
    options = {}
    for key, prefix in prefixes.items():
        candidates = {}
        for n in range(max_padding + 1):
            text = "\n" * n + prefix + question
            tokens = [int(v) for v in tokenize(text)]
            candidates.setdefault(len(tokens), {"text": text, "ids": tokens, "padding_newlines": n})
        options[key] = candidates
    common_lengths = set.intersection(*(set(v) for v in options.values()))
    if not common_lengths:
        raise ValueError("Could not match exact token lengths across prompt conditions")
    target = min(common_lengths)
    result = {key: vals[target] for key, vals in options.items()}
    for row in result.values():
        if not row["text"].endswith(question) or len(row["ids"]) != target:
            raise ValueError("Token match changed question or failed equality")
        row["token_count"] = target
    return result


def exact_token_count_matched(raw_inputs, chat_header_ids, newline_id, max_padding=128):
    """Guarantee equal lengths by inserting literal newline *token IDs*.

    This deliberately constructs a possibly non-canonical BPE tokenization.
    It preserves the exact raw token sequence after the chat role header, with
    all inserted tokens accounted for. Do not call this semantic neutrality.
    """
    if not raw_inputs or not isinstance(chat_header_ids, (tuple, list)) or not chat_header_ids:
        raise ValueError("Invalid chat header or raw inputs")
    if not isinstance(newline_id, int) or newline_id < 0 or max_padding < 0:
        raise ValueError("Invalid newline token or padding budget")
    header = [int(x) for x in chat_header_ids]
    for key, seq in raw_inputs.items():
        if not isinstance(seq, (list, tuple)) or len(seq) <= len(header) or list(seq[:len(header)]) != header:
            raise ValueError(f"Chat header mismatch for {key}")
    target = max(len(seq) for seq in raw_inputs.values())
    result = {}
    for key, seq in raw_inputs.items():
        n = target - len(seq)
        if n > max_padding:
            raise ValueError(f"Prompt exceeds padding budget: {key}, needs {n} tokens")
        ids = header + [newline_id] * n + [int(x) for x in seq[len(header):]]
        if len(ids) != target:
            raise ValueError("Exact token-count matching failed")
        result[key] = {"ids": ids, "padding_tokens": n, "token_count": target,
                       "raw_token_count": len(seq),
                       "matching_method": "explicit_newline_token_ids_after_chat_header"}
    return result


def ensure_complete_grid(rows, question_ids, directions, variants, templates, stage):
    """Reject missing, duplicated, unexpected, or nonfinite scientific records."""
    expected = {(q, d, v, t) for q in question_ids for d in directions for v in variants for t in templates}
    seen = set()
    for row in rows:
        if row.get("stage") != stage:
            raise ValueError("Unexpected stage in factorial grid")
        key = tuple(row[k] for k in ("question_id", "direction", "variant", "template"))
        if key in seen:
            raise ValueError("Duplicate factorial cell")
        seen.add(key)
        if not math.isfinite(float(row["full_attenuation"])):
            raise ValueError("Nonfinite scientific measurement")
    if seen != expected:
        raise ValueError(f"Incomplete or unexpected grid: missing {len(expected-seen)}, extra {len(seen-expected)}")


def paired_question_contrasts(rows):
    """Compute (math_format - generic)_original - (math_format - generic)_reworded."""
    group = {}
    for row in rows:
        q = row["question_id"]
        key = (row["variant"], row["template"])
        if key in group.setdefault(q, {}):
            raise ValueError("Duplicate paired contrast input")
        group[q][key] = float(row["full_attenuation"])
    expected = {(v, t) for v in ("original", "reworded") for t in ("generic", "math_format")}
    out = []
    for q, cells in sorted(group.items()):
        if set(cells) != expected:
            raise ValueError("Incomplete question-level contrast")
        a = cells[("original", "math_format")] - cells[("original", "generic")]
        b = cells[("reworded", "math_format")] - cells[("reworded", "generic")]
        out.append({"question_id": q, "original_mf_minus_generic": a,
                    "reworded_mf_minus_generic": b, "contrast": a-b})
    return out


def bootstrap_mean(values, reps: int = 10000, seed: int = 20261118):
    arr = np.asarray(values, dtype=np.float64)
    if arr.ndim != 1 or len(arr) < 2 or reps < 100 or not np.isfinite(arr).all():
        raise ValueError("Bootstrap requires >=2 finite question-level values, >=100 draws")
    sample = np.random.default_rng(seed).integers(0, len(arr), (reps, len(arr)))
    means = arr[sample].mean(axis=1)
    return {"n_questions": int(len(arr)), "mean": float(arr.mean()),
            "ci95": [float(v) for v in np.quantile(means, [0.025, 0.975])],
            "positive_question_pairs": int((arr > 0).sum()), "bootstrap_reps": int(reps),
            "seed": int(seed)}


def compare_replay(actual, reference, tolerance: float = 0.002):
    """Truthfully report discrepancies on the intersecting archived cells."""
    def mapping(rows):
        out = {}
        for row in rows:
            key = tuple(row[k] for k in ("question_id", "direction", "variant", "template"))
            if key in out:
                raise ValueError("Duplicate replay comparison cell")
            out[key] = float(row.get("full_attenuation", row.get("attenuation")))
        return out
    old = mapping(reference)
    now = mapping(actual)
    if set(old) != set(now) or not now:
        return {"status": "INCOMPLETE", "n_compared": len(set(old) & set(now)),
                "missing_reference": len(set(now)-set(old)), "missing_replay": len(set(old)-set(now))}
    errors = [abs(now[k]-old[k]) for k in now]
    if not all(math.isfinite(e) for e in errors):
        raise ValueError("Nonfinite archive comparison")
    return {"status": "MATCH" if max(errors) <= tolerance else "MISMATCH",
            "n_compared": len(errors), "max_abs_error": max(errors),
            "mean_abs_error": sum(errors)/len(errors), "tolerance": tolerance}


def verified_jsonl(path: Path, expected_protocol_sha256: str):
    """Resume only exact, complete records from this frozen protocol."""
    file = Path(path)
    if not file.exists():
        return {}
    raw = file.read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise ValueError("Partial JSONL record at EOF; preserve file for audit")
    result = {}
    for line in raw.splitlines():
        if not line.strip():
            raise ValueError("Blank JSONL record")
        row = json.loads(line)
        key = row.get("record_key")
        if row.get("protocol_sha256") != expected_protocol_sha256:
            raise ValueError("Protocol drift in resumed record")
        if not isinstance(key, str) or not key:
            raise ValueError("Missing record key")
        if key in result:
            raise ValueError("Duplicate resumed record key")
        result[key] = row
    return result


def inferential_decision(primary, numeric_ok: bool, complete: bool, smoke: bool):
    """Classify a preregistered within-model *response* contrast, not accuracy."""
    if smoke:
        status = "SMOKE_NONINFERENTIAL"
    elif not complete:
        status = "INCOMPLETE"
    elif not numeric_ok:
        status = "NUMERIC_INCONCLUSIVE"
    elif not primary or primary.get("n_questions") != 64:
        status = "INCOMPLETE"
    elif (math.isfinite(float(primary["mean"])) and
          all(math.isfinite(float(x)) for x in primary["ci95"]) and
          float(primary["mean"]) >= 0.10 and float(primary["ci95"][0]) > 0):
        status = "MATCHED_PATTERN_CONFIRMED"
    else:
        status = "NOT_CONFIRMED"
    return {"status": status, "effect_cutoff": 0.10,
            "interpretation": "Within-model prompt-conditioned last-token response geometry only; not accuracy, causal circuit localization, or cross-model generality."}


def export_checked_zip(source_root, output_path):
    """Package only regular files, inside the run, with a verifiable SHA manifest."""
    root = Path(source_root).resolve()
    output = Path(output_path).resolve()
    if output == root or root in output.parents:
        raise ValueError("Export path must be outside source directory")
    files = sorted(path for path in root.rglob("*") if path.is_file())
    if not files:
        raise ValueError("Cannot export empty results")
    manifest = {"algorithm": "sha256", "files": {}}
    for path in files:
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError("Unsafe symlink or file outside results directory")
        rel = path.relative_to(root).as_posix()
        if rel == "CHECKSUMS_SHA256.json":
            raise ValueError("Reserved manifest path")
        manifest["files"][rel] = hashlib.sha256(path.read_bytes()).hexdigest()
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + ".tmp")
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as package:
        for path in files:
            package.write(path, arcname=path.relative_to(root).as_posix())
        package.writestr("CHECKSUMS_SHA256.json", json.dumps(manifest, indent=2, sort_keys=True))
    tmp.replace(output)
    return manifest
